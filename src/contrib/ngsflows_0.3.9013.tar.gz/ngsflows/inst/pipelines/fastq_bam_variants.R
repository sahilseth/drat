
## fetch_bam_haplotype
## fastq_bam_preprocess