
#' Title
#'
#' @param x 
#' @param y 
#' @param samplename 
#' @param outfile 
#' @param is_merged 
#' @param split_by_chr 
#'
#' @export
#'
#' @examples \dontrun{
#' 
#' x = "tumor.bam"
#' y = "normal.bam"
#' 
#' out = mutect(x, y, is_merged = TRUE)
#' 
#' x = "tumor.bam"
#' }
mutect <- function(x, y,
                   samplename = get_opts("samplename"),
                   outfile,
                   is_merged = TRUE,
                   split_by_chr = TRUE, 
                   
                   java_exe = get_opts("java_exe"),
                   java_tmp = get_opts("java_tmp"),
                   
                   mutect_jar = get_opts('mutect_jar'),
                   
                   cpu_mutect = get_opts('cpu_mutect'), ## curently not suported
                   mem_mutect = get_opts("java_mem"),
                   
                   ref_fasta = get_opts('ref_fasta'),
                   
                   mutect_opts = get_opts('mutect_opts')
                   
){
  
  ## determine output file name
  if(missing(outfile))
    bam_prefix <- gsub(".bam", "", basename(x))
  else
    bam_prefix <- outfile
  
  ## if file is available determine whether to split for faster processing
  ## even if the bam files are pre-split its better to explicitily supply the 
  ## chr info
  if(split_by_chr){
    
    ##chrs_info <- get_bam_chrs(x)
    chrs_info <- get_fasta_chrs(ref_fasta)
    chrs_prefix <- paste0(bam_prefix, ".", chrs_info) ## bam names
    intervals_opts = paste0(" -L ", chrs_info)             ## interval files
    
    if(is_merged & length(x) > 1){
      stop("multiple bams supplied, expected 1; perhaps is_merged should be FALSE?")
      
    }else if(!is_merged & length(x) == 1){
      stop("single bam supplied, expected multiple (one fo each chromosome); perhaps is_merged should be TRUE")
    }
  }else{
  ## dont split
    chrs_prefix = paste0(bam_prefix, ".")
    intervals_opts = ""
  }
  
  check_args(ignore = "outfile")
  
  pipename = match.call()[[1]]
  message("Generating a ", pipename, " flowmat for sample: ", samplename)
  
  mutects <- paste0(chrs_prefix, "mutect")
  wigs <- paste0(chrs_prefix, ".wig")
  
  if(!(length(intervals_opts) == length(wigs) | length(intervals_opts) == 1))
    stop("length of intervals should be same as wigs OR 1")
  
  cmd_mutect <- sprintf("%s %s -Djava.io.tmpdir=%s -jar %s --analysis_type MuTect --reference_sequence %s --input_file:tumor %s --input_file:normal %s --out %s  --coverage_file %s %s %s",
                        java_exe, mem_mutect, java_tmp, mutect_jar, ref_fasta, x, y,
                        mutects, wigs, 
                        mutect_opts, intervals_opts)
  cmds <- list(mutect = cmd_mutect)
  
  ## .filter='judgement==KEEP'
  if(split_by_chr){
    merged_mutect = paste0(bam_prefix, "_merged.mutect.txt")
    cmd_merge = sprintf("flowr ngsflows::merge_sheets x=%s outfile=%s", 
                        paste(mutects, collapse = ","), merged_mutect)
    cmds = c(cmds, mutect_merge = cmd_merge)
  }

  flowmat = to_flowmat(cmds, samplename = samplename)
  return(list(flowmat=flowmat, outfiles=mutects))
  
}


#' Title
#'
#' @param fl
#' @param outfile
#'
#' @export
merge_sheets <- function(x, outfile, .filter = NA, ...){
  tmp <- lapply(x, function(fl){
    message(".", appendLF = FALSE)
    tab = read_sheet(fl, ...)
    if(!is.na(.filter)){
      tab2 = dplyr::filter_(tab, .filter)
      return(tab2)
    }else{
      return(tab)
    }
  })
  
  mrgd = do.call(rbind, tmp)
  if(!missing(outfile))
    write_sheet(mrgd, outfile)
  
  invisible(mrgd)
}


#' Title
#'
#' @param x 
#' @param samplename 
#' @param outfile 
#'
#' @export
annotate <- function(x, samplename = get_opts("samplename"), outfile){
  
  if(missing(outfile))
    bam_prefix <- tools::file_path_sans_ext(basename(x[1]))
  else
    bam_prefix <- outfile
  
  anns = paste0(x, "ann.tsv")
  cmd_ann = sprintf("flowr IACSUtil:::annotate_mutect x=%s outfile=%s full=TRUE use_uuid=FALSE", 
                    x, anns)
  
  merged_ann = paste0(bam_prefix, "_merged.annotate.txt")
  cmd_merge = sprintf("flowr ngsflows::merge_sheets x=%s outfile=%s", 
                      paste(anns, collapse = ","), merged_ann)
  cmds = list(annotate = cmd_ann, annotate_merge = cmd_merge)
  
  flowmat = to_flowmat(cmds, samplename = samplename)
  
  return(list(flowmat = flowmat, outfiles = list(merged = merged_ann)))
}

