
#setClass("flowdef", contains = "data.frame")
#http://www.carlboettiger.info/2013/09/11/extending-data-frame-class.html



#' @rdname flowdef
#' @name flow_definition
#' @aliases flowdef to_flowdef
#' @title
#' Flow Definition defines how to stich pieces of the (work)flow into a flow.
#'
#' @description 
#' This function enables creation of a skeleton flow definition with several default values, using a 
#' flowmat.
#' To customize the flowdef, one may supply parameters such as sub_type and dep_type upfront.
#' As such, these params must be of the same length as number of unique jobs using in the flowmat.
#' 
#' {
#' Each row in this table refers to one step of the pipeline. 
#' It describes the resources used by the step and also its relationship with other steps, 
#' especially, the step immediately prior to it.
#' } <br><br>
#' 
#' \strong{Submission types:} 
#' \emph{This refers to the sub_type column in flow definition.}<br>
#' 
#' Consider an example with three steps A, B and C. 
#' A has 10 commands from A1 to A10, similarly B has 10 commands B1 through B10 and 
#' C has a single command, C1.
#' Consider another step D (with D1-D3), which comes after C.
#' 
#' A   ----> B  -----> C -----> D
#' 
#' 
#'  
#' 
#' \itemize{
#' \item \code{scatter}: submit all commands as parallel, independent jobs. 
#' 
#' 	*Submit A1 through A10 as independent jobs*
#' 	\item \code{serial}: run these commands sequentially one after the other. 
#' 	
#' 	- *Wrap A1 through A10, into a single job.*
#'}
#'
#' \strong{Dependency types}
#'
#' \emph{This refers to the dep_type column in flow definition.}
#' 
#' \itemize{
#' \item \code{none}: independent job.
#' 		\itemize{\item *Initial step A has no dependency*}
#' 	\item \code{serial}: *one to one* relationship with previous job. 
#' 	\itemize{\item*B1 can start as soon as A1 completes.*}
#' 	\item \code{gather}: *many to one*, wait for **all** commands in previous job to finish then start the  current step. 
#' 	\itemize{\item *All jobs of B (1-10), need to complete before C1 is started*}
#' 	\item \code{burst}: *one to many* wait for the previous step which has one job and start processing all cmds in the current step. 
#' 	
#' 	- *D1 to D3 are started as soon as C1 finishes.*
#' }
#' 
#' @format
#' This is a tab separated file, with a minimum of 4 columns:<br>
#' 
#' \emph{required columns}:<br>
#' \itemize{
#' \item{\code{jobname}}: Name of the step
#' \item{\code{sub_type}}: Short for submission type, 
#'  refers to, how should multiple commands of this step be submitted. Possible values are `serial` or `scatter`. 
#' \item{\code{prev_jobs}}: Short for previous job, this would be jobname of the previous job. 
#' This can be NA/./none if this is a independent/initial step, and no previous step is required for this to start. 
#' \item{\code{dep_type}}: Short for dependency type, 
#' refers to the relationship of this job with the one defined in `prev_jobs`. 
#' This can take values `none`, `gather`, `serial` or `burst`.
#' }
#' 
#' \emph{resource columns} (recommended):<br>
#' 
#' Apart from the above described variables, 
#' several other variables defining the resource requirements of each step are also available.
#' These give great amount of flexibility to the user in choosing CPU, wall time, memory and queue 
#' for each step (and are passed along to the HPCC platform). 
#' \itemize{
#' 	\item{\code{cpu_reserved}}
#'	\item{\code{memory_reserved}}
#'	\item{\code{nodes}}
#'	\item{\code{walltime}}
#'	\item{\code{queue}}
#' }
#'
#' @param x can a path to a flowmat, flomat or flow object.
#' @param sub_type submission type, one of: scatter, serial. Character, of length one or same as the number of jobnames
#' @param dep_type dependency type, one of: gather, serial or burst. Character, of length one or same as the number of jobnames
#' @param prev_jobs previous job name
#' @param queue Cluster queue to be used
#' @param platform platform of the cluster: lsf, sge, moab, torque, slurm etc.
#' @param memory_reserved amount of memory required.
#' @param cpu_reserved number of cpu's required
#' @param walltime amount of walltime required
#' @inheritParams to_flow
#' @param ... not used
#'
#' @importFrom params kable
#' 
#' @export
to_flowdef <- function(x, ...){
	#message("input x is ", class(x)[1])
	UseMethod("to_flowdef")
	warnings()
}


guess_sub_dep <- function(x){

	lst <- lapply(1:nrow(x), function(i){
		cmds = "";
		prev_job = ""
		d_sub_type <- detect_sub_type(cmds = cmds)
		d_dep_type <- detect_dep_type(prev_job = prev_job, cmds = cmds)
		list(sub_type = d_sub_type, dep_type = d_dep_type)
	})
	return(lst)
}

#' @rdname flowdef
#' @export
to_flowdef.flowmat <- function(x,
															 sub_type,
															 dep_type,
															 prev_jobs,
															 queue = "short",
															 platform = "torque",
															 memory_reserved = "2000", ## in MB
															 cpu_reserved = "1",
															 walltime = "1:00",
															 verbose = get_opts("verbose"), ...){

	if(verbose)
		message("Creating a skeleton flow definition")
	jobnames <- unique(x$jobname)
	if(verbose)
		message("Following jobnames detected: ",
					paste(jobnames, collapse = " "))

	njobs = length(jobnames)
	if(missing(dep_type))
		dep_type = c("none", rep("gather", njobs - 1))
	if(missing(sub_type))
		sub_type = "serial"
	if(missing(prev_jobs))
		prev_jobs = c("none", jobnames[-njobs])

	def <- data.frame(jobname = jobnames,
										sub_type = sub_type,
										prev_jobs = prev_jobs,
										dep_type = dep_type,
										queue = queue,
										memory_reserved = memory_reserved,
										walltime = walltime,
										cpu_reserved = cpu_reserved,
										platform = platform,
										stringsAsFactors = FALSE)

	def = as.flowdef(def)
	return(def)
}



#' @rdname flowdef
#' @export
to_flowdef.flow <- function(x, ...){
	slts = c(jobname = "name",
					 prev_jobs = 'previous_job',
					 dep_type = "dependency_type",
					 sub_type = "submission_type",
					 queue = "queue",
					 memory_reserved = "memory",
					 walltime = "walltime",
					 nodes = "nodes",
					 cpu_reserved = "cpu",
					 status = "status",
					 platform = "platform")
	tmp <- lapply(x@jobs, function(y){
		y = slots_as_list(y)[slts]
		y$previous_job = paste(y$previous_job, collapse = ",")
		unlist(y)
	})
	def = data.frame(do.call(rbind, tmp), stringsAsFactors = FALSE)
	colnames(def) = names(slts)
	#kable(def)
	def = as.flowdef(def)
	return(def)
}


#' @rdname flowdef
#' @importFrom utils write.table
#' @export
to_flowdef.character <- function(x, ...){
	if(!missing(x)){
		mat <- read_sheet(x)
		mat = to_flowmat(mat)
	}
	def = to_flowdef(mat)
	write.table(def, file = file.path(dirname(x), "flowdef.txt"),
							sep = "\t", row.names = FALSE, quote = FALSE)
	invisible(def)
}


#' @rdname flowdef
#' @export
as.flowdef <- function(x, ...){
	## ---- assuming x is a file
	if(is.flowdef(x))
		return(check(x))
	if(is.data.frame(x))
		y = x
	if(is.character(x)){
		if(!file.exists(x))
			stop(paste0(error("no.def"), x))
		message("def seems to be a file, reading it...")
		y <- read_sheet(x, id_column = "jobname")
	}
	y$jobid <- 1:nrow(y)
	class(y) <- c("flowdef", "data.frame")
	y = check(y, ...)
	return(y)
}


#' @rdname flowdef
#' @export
is.flowdef <- function(x){
	class(x)[1] == "flowdef"
}


## needs two new functions:
## check resources
## check relationships



## -----------   this section deals with making a skeleton flowdef


## examples
if(FALSE){
	def = system.file('vignettes/ex_flow2.def', package = "ngsflows")

}





