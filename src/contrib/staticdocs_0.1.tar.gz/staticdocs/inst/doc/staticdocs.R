## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(
  comment = "#>",
  error = FALSE,
  tidy = FALSE
)
library(staticdocs)

## ------------------------------------------------------------------------
sd_section(
  "Settings functions",
  "These functions are used in `index.r` to configure various
    settings that staticdocs uses when rendering a package.  This is
    particularly useful for generating an index page that groups functions
    into useful categories",
  c("sd_icon", "sd_item", "sd_section")
)

