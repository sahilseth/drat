## ----global_options, include=FALSE---------------------------------------
# R output pre blocks are styled to indicate output
# so we don't need to comment out the output
knitr::opts_chunk$set(comment = NA)

