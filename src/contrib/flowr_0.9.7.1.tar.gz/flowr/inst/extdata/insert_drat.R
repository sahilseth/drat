#insert to drat

pkg = devtools::build()

drat::insertPackage("myPkg_0.5.tar.gz", "~/Dropbox/public/github_drat")
