# Added annovar, such that it creates a TSV
- **new** added parse VCF and somatic parse VCF
- **new** added STAR, annovar, mutect

## ngsflows version 0.38
- add way to download genomes from igenomes
- update create_sample_sheet
	- Now create csv/tsv files
