## funr
- funr() outputs a class of `funr`, which is essentially a list.
- This ensures that when print is called, it prints it pretty
