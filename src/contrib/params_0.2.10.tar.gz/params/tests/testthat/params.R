## checking for the following error messages:
"error in read_sheet"
