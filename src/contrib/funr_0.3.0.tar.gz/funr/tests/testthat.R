library(testthat)
library(funr)

test_check("funr")
