

#' @importFrom tools Rd_db
#' @importFrom yaml yaml.load_file
#' @import stringr
build_rdtex <- function(package_name){
	package_name = "flowr"
	rd_index = "~/Dropbox/public/github_flowrpages/flowr/rd_index.yaml"
	
	db <- Rd_db(package_name)
	names(db) <- gsub("\\.Rd", "", names(db))
	
	
	nms <- gsub("\\.Rd", "", names(db))
	
	if(!is.null(rd_index)) {
		rd_index <- yaml.load_file(rd_index)
		rd_topics <- unlist(lapply(rd_index, function(x) x$topics))
		missing_topics <- setdiff(nms, rd_topics)
		if(length(missing_topics) > 0) {
			message("topics in package that were not found in rd_index (will not be included): ", paste(missing_topics, collapse = ", "))
			nms <- setdiff(nms, missing_topics)
		}
		unknown_topics <- setdiff(rd_topics, nms)
		if(length(unknown_topics) > 0) {
			message("topics found in rd_index that aren't in package (will not be included): ", paste(unknown_topics, collapse = ", "))
			for(ii in seq_along(rd_index))
				rd_index[[ii]]$topics <- setdiff(rd_index[[ii]]$topics, unknown_topics)
		}
	} else {
		rd_index <- list(list(section_name = "Package", desc = "", topics = sort(nms)))
	}
	
	for(ii in seq_along(rd_index))
		rd_index[[ii]]$topics <- setdiff(rd_index[[ii]]$topics, error_topics)
	
	
}
