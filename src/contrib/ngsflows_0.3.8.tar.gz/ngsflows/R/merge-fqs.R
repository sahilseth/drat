merge_fqs <- function(x, samplename){
  
}
