#' @title read_paired_samplesheet
#' @description read_paired_samplesheet
#' @param x
#' @param ...
#' @export
read_paired_samplesheet <- function(x, ...){
    ext <- file_ext(x)
    if(ext=="tsv"){
        mat <- read.table(x, as.is=TRUE, sep="\t", header=TRUE)
    }else if(ext=="csv"){
        mat <- read.csv2(x, as.is=TRUE, comment.char = '#', strip.white=TRUE,
                         blank.lines.skip=TRUE, sep=",", header=TRUE)
    }
    mat <- mat[! (is.na(mat$samplename) | mat$samplename %in% c("NA", "NULL", "")), ]
    ## convert paired_mat for xenome, calling snps etc
    single_mat <- rbind(cbind(mat$project, mat$samplename, mat$sampbam, mat$db_sampleid),
                        cbind(mat$project, mat$refname, mat$refbam, mat$db_refid))
    colnames(single_mat) <- c("project", "samplename", "bam", "db_id")
    single_mat <- data.frame(unique(single_mat),stringsAsFactors=FALSE)
    return(list(single_mat=single_mat, paired_mat=mat))
}

## x is a object from seqan_tooling
#' @title create_tooling_paired_samplesheet
#' @description create_tooling_paired_samplesheet
#' @param x
#' @param outfile
#' @param tumor.only
#' @param normal.only
#' @export
create_tooling_paired_samplesheet <- function(x, outfile, tumor.only=FALSE, normal.only=FALSE){
    colnames(x)  <- tolower(colnames(x))
    project=apply(x[,c("project","subproject")], 1, paste, collapse="-")
    if(tumor.only){
        out_mat <- data.frame(project, samplename=x$tumorsampleid, refname=NA,
                              sampbam=x$tumorsamplepreprocbam, refbam=NA,
                              db_sampleid=x$tumorsamplerunitemid, db_refid=0)
    }
    if(!missing(outfile)){
        dir.create(dirname(outfile),recursive=TRUE)
        write.table(out_mat, file=outfile, sep="\t", quote=FALSE, row.names=FALSE)
    }
    return(out_mat)
}

## x is a matrix with two columns sampname refname
## refname can be common_normal_01
#' @title create_paired_samplesheet
#' @description create_paired_samplesheet
#' @param x
#' @param fqmat
#' @param sampbam
#' @param refbam
#' @param outfile
#' @param db_sampleid
#' @param db_refid
#' @param out_prefix
#' @param bampath
#' @param project
#' @param normal_bam_01
#' @export
#' @importFrom tools file_path_sans_ext
create_paired_samplesheet <- function(x, fqmat, 
                                      sampbam, refbam, ## full paths to bam files
                                      outfile, db_sampleid = 0, db_refid = 0, out_prefix, 
                                      bampath, ## to be supplied if fastq sheet is supplied
                                      project = 'project',  subproject = 'subproject',
                                      normal_bam_01 = "/scratch/iacs/ngs/commonNormalBam/ANDY-Hetero-JZ-330-10-01_130425_SN208_0465_BD2705ACXX_merged2_rg.sorted.recalibed.bam"){
  ## if fqmat is available we will get things from here
  if(!missing(fqmat)){
      tmp <- unlist(sapply(x[,1], function(s) fqmat[fqmat$samplename == s, "recal_bam"][1]))
      if(!is.null(tmp)) tmp_sampbam <- tmp
      if(!missing(bampath)) tmp_sampbam = file.path(bampath, tmp_sampbam)
      refbam <- unlist(sapply(x[,2], function(s){  
        if(s == "common_normal_01") return(normal_bam_01)
        fqmat[fqmat$samplename == s, "recal_bam"][1]
      }))    
      project <- unlist(sapply(x[,1], function(s){  
        paste(fqmat[fqmat$samplename == s, c("project","subproject"), drop = FALSE][1,], collapse="-")}))        
  }else{ ## if no fastq sheet is supplied
    refbam <- ifelse(x[,2] == "common_normal_01", normal_bam_01, refbam)
  }
  if(missing(sampbam)) sampbam <- tmp_sampbam ## if missing them replace from fqmat
  if(missing(out_prefix))
    out_prefix = sprintf("%s___%s", basename(file_path_sans_ext(sampbam)), basename(file_path_sans_ext(refbam)))
  out_mat = cbind(project = project, samplename = x[,1], refname = x[,2], sampbam = sampbam, refbam = refbam, 
                  db_sampleid = db_sampleid, db_refid = db_refid, out_prefix = out_prefix)
  write.table(out_mat, file=outfile, sep="\t", quote=FALSE, row.names=FALSE)
  return(out_mat)
}



