.onAttach <- function(lib, pkg){
  packageStartupMessage("Welcome to ngsflows !")
}