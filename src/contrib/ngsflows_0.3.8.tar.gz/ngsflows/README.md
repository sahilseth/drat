### Setup
```
wget ... and download the reference data and files
## wget download the 
## test R
Rscript --version
## get runflow from github, name of the flow, samplesheet, parameterfile
## wget runflow
```


```r
install.packages('devtools')
require(devtools)
install_github(repo = 'ngsflows', username = 'sahilseth')
```
